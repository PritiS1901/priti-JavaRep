package com.java.core;

public class ServiceUnavailableException extends Exception{
}
