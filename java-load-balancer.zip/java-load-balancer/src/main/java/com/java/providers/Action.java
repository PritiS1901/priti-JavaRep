package com.java.providers;

public enum Action {
    LONG_GET,
    GET,
    HEALTH_CHECK,
}
