package com.java.providers;

public enum ProviderStatus {
    OK,
    OUT_OF_SERVICE,
    BUSY,
    TEARDOWN,
}
