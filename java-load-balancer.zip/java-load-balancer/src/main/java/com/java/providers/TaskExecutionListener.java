package com.java.providers;

public interface TaskExecutionListener {

    void taskCompleted();

}
