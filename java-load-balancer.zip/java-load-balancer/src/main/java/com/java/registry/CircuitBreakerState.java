package com.java.registry;

public enum CircuitBreakerState {
    OPEN,
    CLOSED,
}
